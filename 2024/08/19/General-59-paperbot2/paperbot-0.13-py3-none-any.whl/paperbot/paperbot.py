import docx
from docx import Document
from docx import opc
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import sys, os

# head
font_header_name = "Calibri"
font_header_size = Pt(14)
font_header_color = RGBColor(64, 64, 64)

# chapter
font_chapter_name = "Calibri"
font_chapter_size = Pt(12)
font_chapter_color = RGBColor(128, 128, 128)

# body
font_body_name = "Calibri"
font_body_size = Pt(10)
font_body_color = RGBColor(0, 0, 0)


def insertHR(paragraph, color):
    p = paragraph._p  # p is the <w:p> XML element
    pPr = p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    pPr.insert_element_before(pBdr,
        'w:shd', 'w:tabs', 'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap',
        'w:overflowPunct', 'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN',
        'w:bidi', 'w:adjustRightInd', 'w:snapToGrid', 'w:spacing', 'w:ind',
        'w:contextualSpacing', 'w:mirrorIndents', 'w:suppressOverlap', 'w:jc',
        'w:textDirection', 'w:textAlignment', 'w:textboxTightWrap',
        'w:outlineLvl', 'w:divId', 'w:cnfStyle', 'w:rPr', 'w:sectPr',
        'w:pPrChange'
    )
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '12')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)


# Helper function to add hyperlink (since python-docx does not directly support hyperlinks)
def add_hyperlink(paragraph, url, text, color="#0000ff", underline=True):
    """
    A function that places a hyperlink within a paragraph object.

    :param paragraph: The paragraph we are adding the hyperlink to.
    :param url: A string containing the required url
    :param text: The text displayed for the url
    :return: The hyperlink object
    """

    # This gets access to the document.xml.rels file and gets a new relation id value
    part = paragraph.part
    r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)

    # Create the w:hyperlink tag and add needed values
    hyperlink = docx.oxml.shared.OxmlElement('w:hyperlink')
    hyperlink.set(docx.oxml.shared.qn('r:id'), r_id, )

    # Create a w:r element
    new_run = docx.oxml.shared.OxmlElement('w:r')

    # Create a new w:rPr element
    rPr = docx.oxml.shared.OxmlElement('w:rPr')

    # Add color if it is given
    if not color is None:
      c = docx.oxml.shared.OxmlElement('w:color')
      c.set(docx.oxml.shared.qn('w:val'), color)
      rPr.append(c)

    # Remove underlining if it is requested
    if not underline:
      u = docx.oxml.shared.OxmlElement('w:u')
      u.set(docx.oxml.shared.qn('w:val'), 'none')
      rPr.append(u)

    # Join all the xml elements together add add the required text to the w:r element
    new_run.append(rPr)
    new_run.text = text
    hyperlink.append(new_run)

    paragraph._p.append(hyperlink)

    return hyperlink


def apply_style(paragraph, style, font_name=None, font_size=None, font_color=None):
    if style == "header":
        paragraph.style.font.name = font_header_name
        paragraph.style.font.size = font_header_size
        paragraph.style.font.color.rgb = font_header_color
    elif style == "chapter":
        paragraph.style.font.name = font_chapter_name
        paragraph.style.font.size = font_chapter_size
        paragraph.style.font.color.rgb = font_chapter_color
    elif style == "body":
        paragraph.style.font.name = font_body_name
        paragraph.style.font.size = font_body_size
        paragraph.style.font.color.rgb = font_body_color

    # custom paragraph setting
    if font_name:
        paragraph.style.font.name = font_name
    if font_size:
        paragraph.style.font.size = font_size
    if font_color:
        paragraph.style.font.color.rgb = font_color


def init_doc(title, year, authors, journal="", volume="", issue="", pageRange="", articleNo="", doi=""):
    # Create a new Document
    doc = Document()

    # Set title
    para_title = doc.add_heading(title, 1)
    para_title.style.font.name = font_header_name
    para_title.style.font.size = font_header_size
    para_title.style.font.color.rgb = font_header_color
    insertHR(para_title, "#808096")

    # Add authors and journal information
    para_authors = doc.add_paragraph(style='List Bullet')
    para_authors.paragraph_format.left_indent = Inches(0.5)
    para_authors.style.font.name = font_body_name
    para_authors.style.font.size = font_body_size
    para_authors.style.font.color.rgb = font_body_color
    run = para_authors.add_run(authors)
    run.italic=True
    
    journal_info = f"{journal} {volume}"
    if issue and len(issue) > 1:
        journal_info += f", ({issue})"
    if pageRange and len(pageRange) > 1:
        journal_info += f", {pageRange}"
    if articleNo and len(articleNo) > 1:
        journal_info += f", {articleNo}"
    journal_info += f" ({year})"
    para_journal_info = doc.add_paragraph(journal_info, style="List Bullet")
    para_journal_info.paragraph_format.left_indent = Inches(0.5)
    para_journal_info.style.font.name = font_body_name
    para_journal_info.style.font.size = font_body_size
    para_journal_info.style.font.color.rgb = font_body_color
    

    # doi and link
    if len(doi) > 1 and not doi.startswith("https://doi.org/"):
        doi = "https://doi.org/" + doi
    elif len(doi) > 1 and doi.startswith("https://doi.org/"):
        doi = doi
    
    if len(doi) > 1:
        para_doi = doc.add_paragraph("DOI: ", style="List Bullet")
        para_doi.paragraph_format.left_indent = Inches(0.5)
        para_doi.style.font.name = font_body_name
        para_doi.style.font.size = font_body_size
        para_doi.style.font.color.rgb = font_body_color
        add_hyperlink(para_doi, doi, doi)
    
    else:
        pass

    # empty line
    run = para_doi.add_run()
    run.add_break() 

    return doc

def set_cell_border(cell, **kwargs):
    """
    Set cell border
    """
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()

    for edge in ['top', 'left', 'bottom', 'right']:
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = OxmlElement(tag)
            element.set(qn('w:val'), edge_data.get('val', 'single'))
            element.set(qn('w:sz'), str(edge_data.get('sz', 4)))
            element.set(qn('w:space'), str(edge_data.get('space', 0)))
            color = edge_data.get('color', 'auto')
            if isinstance(color, tuple):
                color = '%02x%02x%02x' % color
            element.set(qn('w:color'), color)
            tcPr.append(element)


def add_reference_table(doc, references):
    for ref in references:
        table = doc.add_table(rows=1, cols=1)
        table.style = 'Table Grid'
        cell = table.cell(0, 0)

        # Set cell border with gray color
        gray_color = (128, 128, 128)
        set_cell_border(
            cell,
            top={"sz": 4, "val": "single", "color": gray_color},
            bottom={"sz": 4, "val": "single", "color": gray_color},
            start={"sz": 4, "val": "single", "color": gray_color},
            end={"sz": 4, "val": "single", "color": gray_color}
        )
        # Add citation point
        p_point = cell.paragraphs[0]
        run = p_point.add_run(f"  ※ {ref['citation point']}")
        p_point.style.font.name = font_body_name
        p_point.style.font.size = font_body_size
        # p_point.style.font.color.rgb = RGBColor(64, 128, 128)
        run.bold = True

        # Add authors
        p = cell.add_paragraph(style="List Bullet")
        p.paragraph_format.left_indent = Inches(0.5)
        if isinstance(ref['authors'], list):
            ref['authors'] = ", ".join(ref['authors'])
        else:
            pass
        p.add_run(f"{ref['authors']}")
        p.style.font.name = font_body_name
        p.style.font.size = font_body_size
        p.style.font.color.rgb = font_body_color

        # Add title
        p = cell.add_paragraph(style="List Bullet")
        p.add_run(f"\"{ref['title']}\"")
        p.paragraph_format.left_indent = Inches(0.5)
        p.style.font.name = font_body_name
        p.style.font.size = font_body_size
        p.style.font.color.rgb = font_body_color

        # Add journal and year
        p = cell.add_paragraph(style="List Bullet")
        run = p.add_run(f"{ref['journal']} ")
        run.italic = True
        p.add_run(f"({ref['year']}). ")
        p.paragraph_format.left_indent = Inches(0.5)
        p.style.font.name = font_body_name
        p.style.font.size = font_body_size
        p.style.font.color.rgb = font_body_color

        # Add DOI with hyperlink
        add_hyperlink(p, f"https://doi.org/{ref['doi']}", ref['doi'])

        # Add empty line
        cell.add_paragraph()

    return doc

def add_content(doc, purpose, contribution_academic, contribution_industrial, method_names, method_explanations, 
                originality_names, originality_explanations, limitation_names, limitation_explanations, references):
    # Research purpose
    para = doc.add_paragraph()
    run = para.add_run("1. 연구 목적")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color

    para_purpose = doc.add_paragraph(style="List Bullet")
    para_purpose.paragraph_format.left_indent = Inches(0.5)
    para_purpose.add_run(purpose)
    apply_style(para_purpose, "body")

    # Academic and Industrial Contributions
    para = doc.add_paragraph()
    run = para.add_run("2. 학문적 및 산업적 기여")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color

    para_contribution_academic = doc.add_paragraph(style="List Bullet")
    para_contribution_academic.paragraph_format.left_indent = Inches(0.5)
    para_contribution_academic.style.font.name = font_body_name
    para_contribution_academic.style.font.size = font_body_size
    para_contribution_academic.style.font.color.rgb = font_body_color
    run = para_contribution_academic.add_run("학문적 기여: ")
    run.bold = True
    if isinstance(contribution_academic, list):
        para_contribution_academic.add_run(
            *contribution_academic
        )
    else:
        para_contribution_academic.add_run(
            contribution_academic
        )

    para_contribution_industrial = doc.add_paragraph(style="List Bullet")
    para_contribution_industrial.paragraph_format.left_indent = Inches(0.5)
    para_contribution_industrial.style.font.name = font_body_name
    para_contribution_industrial.style.font.size = font_body_size
    para_contribution_industrial.style.font.color.rgb = font_body_color
    run = para_contribution_industrial.add_run("산업적 기여: ")
    run.bold = True
    if isinstance(contribution_industrial, list):
        para_contribution_industrial.add_run(
            *contribution_industrial,
        )
    else:
        para_contribution_industrial.add_run(
            contribution_industrial,
        )

    # Methods
    para = doc.add_paragraph()
    run = para.add_run("3. 방법론")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color
    for name, expl in zip(method_names, method_explanations):
        para_method = doc.add_paragraph(style="List Bullet")
        para_method.paragraph_format.left_indent = Inches(0.5)
        para_method.style.font.name = font_body_name
        para_method.style.font.size = font_body_size
        para_method.style.font.color.rgb = font_body_color
        run = para_method.add_run(f"{name}: ")
        run.bold = True
        para_method.add_run(
            expl
        )

    # Originality
    para = doc.add_paragraph()
    run = para.add_run("4. 독창성")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color
    for name, expl in zip(originality_names, originality_explanations):
        para_originality = doc.add_paragraph(style="List Bullet")
        para_originality.paragraph_format.left_indent = Inches(0.5)
        para_originality.style.font.name = font_body_name
        para_originality.style.font.size = font_body_size
        para_originality.style.font.color.rgb = font_body_color
        run = para_originality.add_run(f"{name}: ")
        run.bold = True
        para_originality.add_run(
            expl
        )

    # Limitation
    para = doc.add_paragraph()
    run = para.add_run("5. 한계점")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color
    for name, expl in zip(limitation_names, limitation_explanations):
        para_limitation = doc.add_paragraph(style="List Bullet")
        para_limitation.paragraph_format.left_indent = Inches(0.5)
        para_limitation.style.font.name = font_body_name
        para_limitation.style.font.size = font_body_size
        para_limitation.style.font.color.rgb = font_body_color
        run = para_limitation.add_run(f"{name}: ")
        run.bold = True
        para_limitation.add_run(
            expl
        )

    # References
    para = doc.add_paragraph()
    run = para.add_run("6. 주요 레퍼런스")
    run.bold = True
    para.style.font.name = font_chapter_name
    para.style.font.size = font_chapter_size
    para.style.font.color.rgb = font_chapter_color
    doc = add_reference_table(doc, references)

    return doc




def save_doc(doc, authors, journal, year):

    # Save the document
    today_date = datetime.today().strftime('%Y%m%d')
    if isinstance(authors, str):
        authors = authors.split(",")
    filename = f"{today_date}_{authors[0].replace(' ', '')}_{journal.replace(' ', '')}_{year}.docx"

    working_path = os.getcwd()
    filename = os.path.join(working_path, filename)
    doc.save(filename)

    return filename


def gen_doc(title, year, authors, journal="", volume="", issue="", pageRange="", articleNo="", doi="", 
            purpose="", contribution_academic="", contribution_industrial="", method_names=[], method_explanations=[], 
            originality_names=[], originality_explanations=[], limitation_names=[], limitation_explanations=[], references=[]):
    doc = init_doc(title, year, authors, journal, volume, issue, pageRange, articleNo, doi)
    doc = add_content(doc, purpose, contribution_academic, contribution_industrial, method_names, method_explanations, originality_names, originality_explanations, limitation_names, limitation_explanations, references)
    filename = save_doc(doc, authors, journal, year)
    print(f"Document created: {filename}")

    return filename