import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns

import os
import subprocess
import numpy as np

sns.set_style("ticks")


def apply_matplotlibrc(file_path ="matplotlibrc"):
    """
    # Author: Jehyun Lee (jehyun.lee@gmail.com)
    # Date : 2024.09.08.

    Apply settings from a matplotlibrc file to the current matplotlib configuration.

    This function reads a matplotlibrc file, parses its contents, and applies the
    non-commented settings to the current matplotlib configuration. If the file is
    not found, it prints a message indicating so.

    Parameters:
    -----------
    file_path : str, optional
        The path to the matplotlibrc file. Defaults to "matplotlibrc" in the current directory.

    Returns:
    --------
    dict or None
        A dictionary containing the parsed non-commented settings from the matplotlibrc file,
        or None if the file is not found.

    Notes:
    ------
    - Lines starting with '#' in the matplotlibrc file are treated as comments and ignored.
    - Each non-comment line should be in the format "key: value".
    - The function uses plt.rcParams to apply the settings globally to matplotlib.
    """
    def parse_matplotlibrc(file_path):
        matplotlibrc = {}
        with open(file_path, 'r') as file:
            for line in file:
                stripped_line = line.strip()
                if stripped_line and not stripped_line.startswith('#'):
                    k, v = stripped_line.split("#")[0].strip().split(":", 1)
                    matplotlibrc.update({k.strip(): v.strip()})
        return matplotlibrc

    if os.path.exists(file_path):
        non_commented_lines = parse_matplotlibrc(file_path)
        for k, v in non_commented_lines.items():
            plt.rcParams[k] = v

        return non_commented_lines
    
    else:
        print("matplotlibrc file not found in the current directory.")
        return None


def make_figure_axes(nrows=1, ncols=1, figsize=plt.rcParams["figure.figsize"], 
                     axessize=None, **kwargs):
    """
    # Author: Jehyun Lee (jehyun.lee@gmail.com)
    # Date : 2024.09.08.
    
    Create a figure and a grid of axes.

    This function creates a matplotlib figure with a specified number of rows and columns of axes.
    It allows for customization of the figure size and individual axes sizes.

    Parameters:
    -----------
    nrows : int, optional
        Number of rows in the grid of axes. Default is 1.
    ncols : int, optional
        Number of columns in the grid of axes. Default is 1.
    figsize : tuple of float, optional
        Figure size (width, height) in inches. Default is from plt.rcParams["figure.figsize"].
    axessize : tuple of float, optional
        Size (width, height) of each individual axes in inches. If provided, it overrides figsize.
    **kwargs : dict, optional
        Additional keyword arguments to be passed to plt.subplots().

    Returns:
    --------
    fig : matplotlib.figure.Figure
        The created figure object.
    axes : numpy.ndarray
        A 2D array of axes objects. For a single subplot, it's wrapped in a 2D array for consistency.

    Notes:
    ------
    - If axessize is provided, the figure size is calculated by multiplying axessize by the number of rows and columns.
    - The function ensures that the returned axes are always a 2D numpy array, regardless of the number of subplots.
    - For a single subplot (nrows=1, ncols=1), the axes object is wrapped in a 2D numpy array for consistency with multi-subplot cases.
    """
    if axessize:
        figsize = [axessize[0] * ncols, axessize[1] * nrows]
    
    fig, axes = plt.subplots(nrows, ncols, figsize=figsize, **kwargs)

    if nrows == 1 and ncols == 1:
        axes = np.expand_dims(np.expand_dims(axes, axis=0), axis=1)
    elif nrows == 1:
        axes = np.expand_dims(axes, axis=0)
    elif ncols == 1:
        axes = np.expand_dims(axes, axis=1)

    return fig, axes